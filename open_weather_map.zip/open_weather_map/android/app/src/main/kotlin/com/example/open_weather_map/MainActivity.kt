package com.example.open_weather_map

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
